All +ve sums indicates that this useer will pay -ve indicates this user will get

in UserPaymentMap

BalanceRegister :
Have payment flow structure per group as in 
User A: (will pay/recieve depending on sign ahead of value)
{User B: (sign) value}

