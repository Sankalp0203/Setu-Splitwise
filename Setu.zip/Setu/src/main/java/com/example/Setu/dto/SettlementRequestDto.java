package com.example.Setu.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SettlementRequestDto {
    public Integer userIdA;
    public Integer userIdB;
}
